var app =  angular.module('myApp',[]);

app.filter('daterange', function ()
{
  return function(conversations, start_date, end_date)
  {
    console.log('1 ='+ conversations, start_date, end_date)
    var result = [];
    // date filters
    var start_date = (start_date && !isNaN(Date.parse(start_date))) ? Date.parse(start_date) : 0;
    var end_date = (end_date && !isNaN(Date.parse(end_date))) ? Date.parse(end_date) : new Date().getTime();
  console.log(conversations.length, start_date, end_date);    
    // if the conversations are loaded
    if (conversations && conversations.length > 0)
    {
      $.each(conversations, function (index, conversation)
      {
        var conversationDate = new Date(conversation.availability[0].from).getTime();
         console.log('conversationDate', conversationDate, conversationDate >= start_date, conversationDate <= end_date); 
        if (conversationDate >= start_date && conversationDate <= end_date) {
          console.log('conversation', conversation);  
          result.push(conversation);
        }
      });

      return result;
    }
  };
});


app.controller('MyController', function($scope,$http,$window){
   
$scope.minPrice = 0;
$scope.maxPrice = 999999;  
//$scope.startDate = '10-10-2002';
//$scope.endDate = '10-10-2050';
  
  function getData() {
        $http({
			method : 'GET',
			url : 'https://api.myjson.com/bins/tl0bp'
		}).success(function(data, status, headers, config) {
			$scope.data = data.hotels;	
		}).error(function(data, status, headers, config) {
			alert( "failure");
		});
	    
  };
  getData();


//$scope.data = [{"name":"Media One Hotel","price":102.2,"city":"dubai","availability":[{"from":"10-10-2020","to":"15-10-2020"},{"from":"25-10-2020","to":"15-11-2020"},{"from":"10-12-2020","to":"15-12-2020"}]},{"name":"Rotana Hotel","price":80.6,"city":"cairo","availability":[{"from":"10-10-2020","to":"12-10-2020"},{"from":"25-10-2020","to":"10-11-2020"},{"from":"05-12-2020","to":"18-12-2020"}]},{"name":"Le Meridien","price":89.6,"city":"london","availability":[{"from":"01-10-2020","to":"12-10-2020"},{"from":"05-10-2020","to":"10-11-2020"},{"from":"05-12-2020","to":"28-12-2020"}]},{"name":"Golden Tulip","price":109.6,"city":"paris","availability":[{"from":"04-10-2020","to":"17-10-2020"},{"from":"16-10-2020","to":"11-11-2020"},{"from":"01-12-2020","to":"09-12-2020"}]},{"name":"Novotel Hotel","price":111,"city":"Vienna","availability":[{"from":"20-10-2020","to":"28-10-2020"},{"from":"04-11-2020","to":"20-11-2020"},{"from":"08-12-2020","to":"24-12-2020"}]},{"name":"Concorde Hotel","price":79.4,"city":"Manila","availability":[{"from":"10-10-2020","to":"19-10-2020"},{"from":"22-10-2020","to":"22-11-2020"},{"from":"03-12-2020","to":"20-12-2020"}]}];



});